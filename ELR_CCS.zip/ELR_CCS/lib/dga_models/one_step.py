import torch
import torch.nn as nn
from cmrin_models.model_utils import NormalizeScale
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import math
import pdb


class GraphR(nn.Module):
    def __init__(self, opt):
        super(GraphR, self).__init__()

        dim_word_embed = opt['word_embedding_size']
        dim_word_output = opt['rnn_hidden_size'] * (2 if opt['bidirectional'] else 1)

        self.feat_normalizer = NormalizeScale(opt['dim_input_vis_feat'], opt['vis_init_norm'])
        self.label_normalizer = NormalizeScale(opt['rnn_hidden_size'], opt['vis_init_norm'])
        dim_input_vis_feat = opt['dim_input_vis_feat']
        self.word_normalizer = NormalizeScale(dim_word_embed, opt['word_init_norm'])

        self.nrel_l = opt['num_location_relation']
        

        self.T_ctrl = opt['T_ctrl']

        dim_reason = opt['dim_reason']
        self.Tanh = nn.Tanh()
        #########################################ke############################################################3
        self.block = 3
        ############################multi-branch fusion#################################################################33333
        self.label_compress = nn.Linear(opt['rnn_hidden_size'] * 2, opt['rnn_hidden_size'])
        self.sentece_fuse = nn.Linear(dim_word_embed + dim_word_output, dim_word_output)
        self.W_f1= nn.Linear(dim_word_output * 2, dim_word_output)
        self.W_f2 = nn.Linear(dim_word_output, dim_word_output)
        self.W_femb = nn.Linear(dim_word_output * 2, dim_word_output)
        
        #multi-perspective fusion
        self.encode_que_list_branch = nn.ModuleList([nn.Sequential(nn.Linear(dim_word_output, dim_word_output),
                                                            nn.Tanh(),
                                                            nn.Linear(dim_word_output, dim_word_output))])

        for i in range(0, self.block):
            self.encode_que_list_branch.append(nn.Sequential(nn.Linear(dim_word_output, dim_word_output),
                                                      nn.Tanh(),
                                                      nn.Linear(dim_word_output, dim_word_output)))
            
        self.W_e12 = nn.Linear(dim_word_output, opt['rnn_hidden_size'])
        ############################multi-branch fusion#################################################################33333

        ############################inter-modalsemantic calibration#################################################################33333
        self.W_beta3 = nn.Linear(dim_word_output, opt['rnn_hidden_size'])
        self.W_beta2 = nn.Linear(dim_word_output, dim_word_output)
        self.relu = nn.ReLU()
        self.W_beta1 = nn.Linear(dim_word_output, opt['rnn_hidden_size'])
    
        self.encode_que_list_inter = nn.ModuleList([nn.Sequential(nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size']),
                                                            nn.Tanh(),
                                                            nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size']))])

        for i in range(0, self.block):
            self.encode_que_list_inter.append(nn.Sequential(nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size']),
                                                      nn.Tanh(),
                                                      nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size'])))

        self.W_e34 = nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size'])
        ############################inter-modalsemantic calibration#################################################################33333

        ############################intra-modalsemantic calibration#################################################################33333
        self.W_b4 = nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size'])
        self.W_b3 = nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size'])
        self.W_b2 = nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size'])
        self.W_b1 = nn.Linear(opt['rnn_hidden_size'], opt['rnn_hidden_size'])
        self.W_w = nn.Linear(opt['rnn_hidden_size'], 1)
        ############################intra-modalsemantic calibration#################################################################33333
        self.fuse_node = nn.Linear(opt['rnn_hidden_size'] + dim_word_output, dim_word_output)
        self.node_sentences = nn.Linear(dim_word_output * 2, dim_word_output)
        self.node_weights = nn.Linear(dim_word_output, 1)
        self.le1 = nn.Linear(dim_word_output * 2, dim_word_output)
        self.le2 = nn.Linear(dim_word_output, 1)
        self.ve1 = nn.Linear(dim_word_output * 2, dim_word_output)
        self.ve2 = nn.Linear(dim_word_output, 1)

        self.ee = nn.Linear(dim_word_output * 2, dim_word_output)
        self.l1 = nn.Linear(dim_word_output, dim_word_output)
        self.l2 = nn.Linear(dim_word_output, 1)

        #######################################ke############################################################3


        # update feature
        self.w1 = Parameter(torch.FloatTensor(dim_reason, dim_reason))
        self.w3 = Parameter(torch.FloatTensor(dim_reason, dim_reason))
        self.rel_bias = Parameter(torch.FloatTensor(self.nrel_l, dim_reason))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.w1.size(1))
        self.w1.data.uniform_(-stdv, stdv)
        self.w3.data.uniform_(-stdv, stdv)
        self.rel_bias.data.uniform_(-stdv, stdv)

    def forward(self, visual_feature, expression_guided_labels, q_encoding, q_weight, embed, cls, rel):
        #pdb.set_trace()
        #clip_feature = self.clip_trans(visual_feature)
        #x = self.feat_normalizer(clip_feature)
        label_feature = self.label_compress(expression_guided_labels)
        x = self.feat_normalizer(visual_feature)
        L = self.label_normalizer(label_feature)
        words = self.word_normalizer(embed)
        
        #valid cound
        is_not_pad_node = (cls != -1.0).float()
        valid_node_count = torch.zeros((is_not_pad_node.size(0)), requires_grad=False).cuda()

        for i in range(0, is_not_pad_node.size(0)):
            for j in range(0, is_not_pad_node.size(1)):
                if is_not_pad_node[i][j] == 1:
                    valid_node_count[i] = valid_node_count[i] + 1

        #########################################ke############################################################3

        #setence embedding
        q_weight_expand = q_weight.unsqueeze(2).expand(q_weight.size(0), q_weight.size(1), words.size(2))
        q_vector = (q_weight_expand * words).sum(1)
        #pdb.set_trace()
        sentence_features = self.sentece_fuse(torch.cat([q_vector, q_encoding], 1))

        #multi-branch fusion
        o = self.W_f1(x)
        l = self.W_f2(expression_guided_labels)
        o_l = self.W_femb(torch.cat([o, l], 2))
        branch_block = torch.zeros((o_l.size(0), self.block, o_l.size(1), o_l.size(2))).cuda()
        #pdb.set_trace()
        for i in range(0, self.block):
            branch_block[:,i,:,:] = self.encode_que_list_branch[i](o_l)
    
        branch_block_trans = self.W_e12(branch_block)
        # Inter-modal Semantic 
        o_l_W3 = self.W_beta3(o_l)
        label_W1 = self.W_beta1(self.relu(self.W_beta2(expression_guided_labels)))
        c = o_l_W3 * label_W1
        #pdb.set_trace()
        inter_block = torch.zeros((c.size(0), self.block, c.size(1), c.size(2))).cuda()
        for i in range(0, self.block):
           inter_block[:,i,:,:] = self.encode_que_list_inter[i](c)
        
        inter_block_trans = self.W_e34(inter_block)
        inter_block_trans = branch_block_trans + inter_block_trans
        #pdb.set_trace()
        #Intra-modal Semantic
        intra_block_trans = torch.zeros((inter_block_trans.size(0), inter_block_trans.size(1), inter_block_trans.size(2), inter_block_trans.size(3))).cuda()
        for i in range(0, inter_block_trans.size(2)):
            selected_bolck = inter_block_trans[:,:,i,:]
            selected_bolck_expand = selected_bolck.unsqueeze(2).expand(selected_bolck.size(0), selected_bolck.size(1), inter_block_trans.size(2), selected_bolck.size(2))
            inter_block_trans_compared  =  self.W_b1(selected_bolck_expand) * self.W_b2(inter_block_trans)
            #pdb.set_trace()
            intra_scores = self.W_w(inter_block_trans_compared).squeeze(3)
            #intra_scores_norm = F.softmax(intra_scores, dim = 2)
            #pdb.set_trace()
            is_not_pad_node_expand = is_not_pad_node.unsqueeze(1).expand(is_not_pad_node.size(0), intra_scores.size(1), is_not_pad_node.size(1))
            intra_scores_norm_pad =  intra_scores * is_not_pad_node_expand
            #pdb.set_trace()

            for j in range(0,intra_scores_norm_pad.size(1)):
                #pdb.set_trace()
                j_intra_scores_norm_weight_sum = torch.sum(intra_scores_norm_pad[:,j,:], dim=1).unsqueeze(1).expand(intra_scores_norm_pad[:,j,:].size(0), intra_scores_norm_pad[:,j,:].size(1))
                intra_scores_norm_pad[:,j,:][j_intra_scores_norm_weight_sum != 0] = intra_scores_norm_pad[:,j,:][j_intra_scores_norm_weight_sum != 0] / j_intra_scores_norm_weight_sum[j_intra_scores_norm_weight_sum != 0]
            #pdb.set_trace()
            intra_scores_norm_pad_expand = intra_scores_norm_pad.unsqueeze(3).expand(intra_scores_norm_pad.size(0), intra_scores_norm_pad.size(1), intra_scores_norm_pad.size(2), inter_block_trans.size(3))
            #pdb.set_trace()
            g = self.W_b3(inter_block_trans) * intra_scores_norm_pad_expand
            i_g = torch.sum(g, dim = 2)
            intra_block_trans[:,:,i,:] = self.W_b4(i_g) + inter_block_trans[:,:,i,:]
        #########################################ke############################################################3  
        # iterator
        x_node_gate = torch.zeros((x.size(0), x.size(1)), requires_grad=False).cuda()
        l_node_gate = torch.zeros((expression_guided_labels.size(0), expression_guided_labels.size(1)), requires_grad=False).cuda()
        # edge_type_gate = torch.zeros((edge_type_weight.size(0), edge_type_weight.size(2)), requires_grad=False).cuda()
        x_list = []
        l_list = []
        for T in range(self.T_ctrl):
            if T == 0:
                #visual node definition
                vision_embeddings = torch.sum(intra_block_trans, dim=1) / self.block
                sentence_features_expand = sentence_features.unsqueeze(1).expand(sentence_features.size(0), vision_embeddings.size(1), sentence_features.size(1))
                visual_node_features = self.fuse_node(torch.cat([vision_embeddings, sentence_features_expand], 2))
                label_node_features = self.fuse_node(torch.cat([L, sentence_features_expand], 2))
                # my visual and label node weight
                #pdb.set_trace() 
                visual_node_weights = self.node_weights(self.Tanh(self.node_sentences(torch.cat([visual_node_features, sentence_features_expand], 2)))).squeeze(2) 
                label_node_weights = self.node_weights(self.Tanh(self.node_sentences(torch.cat([label_node_features, sentence_features_expand], 2)))).squeeze(2)             

                is_not_pad_node_expand_edge = is_not_pad_node.unsqueeze(1).expand(is_not_pad_node.size(0), label_node_features.size(1), is_not_pad_node.size(1))

                # my label edge weight
                L_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(2))).cuda()
                #pdb.set_trace()
                for i in range(0, label_node_features.size(1)):
                    #pdb.set_trace()
                    e_L_i = label_node_features[:,i,:]
                    e_L_i_expand = e_L_i.unsqueeze(1).expand(e_L_i.size(0), label_node_features.size(1), e_L_i.size(1))
                    L_c_i = torch.cat([label_node_features, e_L_i_expand], 2)
                    L_fus_i = self.Tanh(self.le1(L_c_i))
                    L_edge_score_i = self.le2(L_fus_i).squeeze(2)
                    L_edge_score[:,:,i] = L_edge_score_i
                
                #pdb.set_trace()
                #L_edge_score_norm = F.softmax(L_edge_score, dim = 2)
                label_edge_weights = L_edge_score *  is_not_pad_node_expand_edge
                l_node_gate, l_i = self.go_node(label_node_weights, expression_guided_labels)


                #my node edge weight
                v_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(2))).cuda()
                #pdb.set_trace()
                for i in range(0, visual_node_features.size(1)):
                    ##pdb.set_trace()
                    e_v_i = visual_node_features[:,i,:]
                    e_v_i_expand = e_v_i.unsqueeze(1).expand(e_v_i.size(0), visual_node_features.size(1), e_v_i.size(1))
                    v_c_i = torch.cat([visual_node_features, e_v_i_expand], 2)
                    v_fus_i = self.Tanh(self.ve1(v_c_i))
                    v_edge_score_i = self.ve2(v_fus_i).squeeze(2)
                    v_edge_score[:,:,i] = v_edge_score_i
                
                #pdb.set_trace()
                #v_edge_score_norm = F.softmax(v_edge_score, dim = 2)
                node_edge_weights = v_edge_score * is_not_pad_node_expand_edge
                v_node_gate, v_i = self.go_node(visual_node_weights, visual_node_features)
                #pdb.set_trace()
               
            else:
                if T == 1:
                    v_node_gate, x_i = self.go(v_node_gate, visual_node_weights, v_i, node_edge_weights, cls, rel)
                    l_node_gate, l_i = self.go(l_node_gate, label_node_weights, l_i, label_edge_weights, cls, rel)

                else:
                    #########################################ke############################################################3
                    #my visual node weight
                    visual_node_weights = self.node_weights(self.Tanh(self.node_sentences(torch.cat([x_i, sentence_features_expand], 2)))).squeeze(2) 
                    label_node_weights = self.node_weights(self.Tanh(self.node_sentences(torch.cat([l_i, sentence_features_expand], 2)))).squeeze(2)         
                    #my visual_edge weight
                    v_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(1)), requires_grad=False).cuda()
                    sentence_features_edge_expand = sentence_features.unsqueeze(1).expand(sentence_features.size(0), x_i.size(1), sentence_features.size(1))
                    #pdb.set_trace()
                    for i in range(0, x_i.size(1)):
                        ##pdb.set_trace()
                        x_ii_expand = x_i[:,i,:].unsqueeze(1).expand(x_i[:,i,:].size(0), x_i.size(1), x_i[:,i,:].size(1))
                        x_c_i = torch.cat([x_i, x_ii_expand], 2)
                        x_fus_i = self.ee(x_c_i)
                        #pdb.set_trace()
                        v_edge_score_i = self.l2(self.Tanh(self.l1(sentence_features_edge_expand) + x_fus_i)).squeeze(2)
                        v_edge_score[:,:,i] = v_edge_score_i
                    #pdb.set_trace()
                    v_edge_score = F.softmax(v_edge_score, dim = 2)
                    v_edge_weight = is_not_pad_node_expand_edge * v_edge_score

                    #pdb.set_trace()
                    #visual mean
                    v_node_weight_mean = torch.zeros((is_not_pad_node.size(0)), requires_grad=False).cuda()
                    for i in range(0, is_not_pad_node.size(0)):
                        v_node_weight_mean[i] = visual_node_weights[i].sum() / valid_node_count[i]
                    
                    for i in range(0, is_not_pad_node.size(0)):
                        for j in range(0, is_not_pad_node.size(1)):
                            if visual_node_weights[i][j] < v_node_weight_mean[i]:
                                visual_node_weights[i][j]= 0
                    #pdb.set_trace()
                    #go
                    #pdb.set_trace()
                    v_node_gate, x_i = self.go(v_node_gate, visual_node_weights, x_i, v_edge_weight, cls, rel)

                    #pdb.set_trace()
                    #my label_edge weight
                    l_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(1)), requires_grad=False).cuda()
                    for i in range(0, l_i.size(1)):
                        ##pdb.set_trace()
                        l_ii_expand = l_i[:,i,:].unsqueeze(1).expand(l_i[:,i,:].size(0), l_i.size(1), l_i[:,i,:].size(1))
                        #pdb.set_trace()
                        l_c_i = torch.cat([l_i, l_ii_expand], 2)
                        l_fus_i = self.ee(l_c_i)

                        l_edge_score_i = self.l2(self.Tanh(self.l1(sentence_features_edge_expand) + l_fus_i)).squeeze(2)
                        l_edge_score[:,:,i] = l_edge_score_i
                    
                    l_edge_score = F.softmax(l_edge_score, dim = 2)
                    l_edge_weights = is_not_pad_node_expand_edge * l_edge_score


                    
                    #label mean
                    l_node_weight_mean = torch.zeros((is_not_pad_node.size(0)), requires_grad=False).cuda()

                    for i in range(0, is_not_pad_node.size(0)):
                        l_node_weight_mean[i] = label_node_weights[i].sum() / valid_node_count[i]

                    for i in range(0, is_not_pad_node.size(0)):
                        for j in range(0, is_not_pad_node.size(1)):
                            if label_node_weights[i][j] < l_node_weight_mean[i]:
                                label_node_weights[i][j]= 0

                    #go
                    #pdb.set_trace()
                    l_node_gate, l_i = self.go(l_node_gate, label_node_weights, l_i, l_edge_weights, cls, rel)
                    #########################################ke############################################################3

                x_list.append(x_i)
                l_list.append(l_i)
        
        
        return x_list[-1], l_list[-1]

    def go(self, last_node_gate, node_weight, last_x, edge_weights, cls, rel):
        
        rel.requires_grad = False
        l_last_x = torch.matmul(last_x, self.w1)
        x3 = torch.matmul(last_x, self.w3)
        x1_t = torch.zeros((l_last_x.size(0), l_last_x.size(1), l_last_x.size(2)), requires_grad=False).cuda()

        last_node_gate_expand = last_node_gate.unsqueeze(2).expand(last_node_gate.size(0), last_node_gate.size(1), last_node_gate.size(1))
         
        for i in range(self.nrel_l):
            adj1_un = (rel == i).detach()
            adj1 = adj1_un.transpose(2, 1).float()
      
            gate_matrix_1 = edge_weights                                                                             
            gate_adj1 = gate_matrix_1 * adj1
            gate_adj1 = gate_adj1 * last_node_gate_expand
            x1_t = x1_t + torch.bmm(gate_adj1, l_last_x) + \
                                    self.rel_bias[i].unsqueeze(0).unsqueeze(1).expand(adj1.size(0),
                                                                                      adj1.size(1),
                                                                                      self.rel_bias.size(1)) * \
                                    gate_adj1.sum(2).unsqueeze(2).expand(adj1.size(0), adj1.size(1),
                                                                         self.rel_bias.size(1))


        #pdb.set_trace()
        adj1_un = (rel == i).detach()
        adj1 = adj1_un.transpose(2, 1).float()



        adj3 = torch.ones((x3.size(0), x3.size(1)), requires_grad=False).cuda()
        adj3[cls == -1] = 0.0
        adj3 = adj3.unsqueeze(2)
        adj3_weight = adj3
        x3_t = x3 * adj3_weight.expand(adj3.size(0), adj3.size(1), x3.size(2))

        x_new = F.relu(x1_t + x3_t)

        # update gate
        new_gate = node_weight
        new_gate_expand = new_gate.unsqueeze(2).expand(-1, -1, x1_t.size(2))
        total_gate = last_node_gate + new_gate
        total_gate_expand = total_gate.unsqueeze(2).expand(-1, -1, x1_t.size(2))
        x_combine = new_gate_expand * x_new + last_node_gate.unsqueeze(2).expand(-1, -1, last_x.size(2)) * last_x
        x_combine[total_gate_expand != 0] = x_combine[total_gate_expand != 0] / total_gate_expand[total_gate_expand != 0]

        return total_gate, x_combine

    def go_node(self, node_weight, x_ini):
        return node_weight, x_ini

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + '->' \
               + str(self.out_features) + ')'
