import torch
import torch.nn as nn
from torch.nn.parameter import Parameter
import math
import torch.nn.functional as F
import pdb


class Controller(nn.Module):

    def __init__(self, dim_word_output, T_ctrl):
        super(Controller, self).__init__()
        ctrl_dim = dim_word_output

        # define c_0 and reset_parameters
        self.c_init = Parameter(torch.FloatTensor(1, ctrl_dim))
        self.reset_parameters()

        self.sub = nn.Linear(ctrl_dim, 1)
        self.intra = nn.Linear(ctrl_dim, 1)
        self.inter = nn.Linear(ctrl_dim, 1)


        self.T_ctrl = T_ctrl

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.c_init.size(1))
        self.c_init.data.uniform_(-stdv, stdv)

    def forward(self, lstm_seq, attn_mask):
        mask = (1.0 - attn_mask.float()) * (-1e30)
        sub_score = self.sub(lstm_seq).squeeze(2) + mask
        intra_score = self.intra(lstm_seq).squeeze(2) + mask
        inter_score = self.inter(lstm_seq).squeeze(2) + mask

        
        sub_weight_t = F.softmax(sub_score, dim = 1) 
        intra_weight_t = F.softmax(intra_score, dim = 1) 
        inter_weight_t = F.softmax(inter_score, dim = 1)

        sub_weight = sub_weight_t * attn_mask.float()
        intra_weight = intra_weight_t * attn_mask.float()
        inter_weight = inter_weight_t * attn_mask.float()


        

        sub_weight_sum = torch.sum(sub_weight, dim=1).unsqueeze(1).expand(sub_weight.size(0), sub_weight.size(1))
        sub_weight[sub_weight_sum != 0] = sub_weight[sub_weight_sum != 0] / sub_weight_sum[sub_weight_sum != 0]

        intra_weight_sum = torch.sum(intra_weight, dim=1).unsqueeze(1).expand(intra_weight.size(0), intra_weight.size(1))
        intra_weight[intra_weight_sum != 0] = intra_weight[intra_weight_sum != 0] / intra_weight_sum[intra_weight_sum != 0]

        inter_weight_sum = torch.sum(inter_weight, dim=1).unsqueeze(1).expand(inter_weight.size(0), inter_weight.size(1))
        inter_weight[inter_weight_sum != 0] = inter_weight[inter_weight_sum != 0] / inter_weight_sum[inter_weight_sum != 0]



        return sub_weight, intra_weight, inter_weight
