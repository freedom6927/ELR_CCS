import torch
import torch.nn as nn
from cmrin_models.model_utils import NormalizeScale
from models.language import RNNEncoder
from dga_models.controller import Controller
from dga_models.one_step import GraphR
from cmrin_models.matching import Matching
import torch.nn.functional as F
import pdb

class MLP(nn.Module):
    """ Very simple multi-layer perceptron (also called FFN)"""

    def __init__(self, input_dim, hidden_dim, output_dim, num_layers):
        super().__init__()
        self.num_layers = num_layers
        h = [hidden_dim] * (num_layers - 1)
        self.layers = nn.ModuleList(nn.Linear(n, k) for n, k in zip([input_dim] + h, h + [output_dim]))

    def forward(self, x):
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < self.num_layers - 1 else layer(x)
        return x

class CR(nn.Module):

    def __init__(self, opt):
        super(CR, self).__init__()

        # language model
        self.rnn_encoder = RNNEncoder(vocab_size=opt['vocab_size'],
                                      word_embedding_size=opt['word_embedding_size'],
                                      hidden_size=opt['rnn_hidden_size'],
                                      bidirectional=opt['bidirectional'] > 0,
                                      input_dropout_p=opt['word_drop_out'],
                                      dropout_p=opt['rnn_drop_out'],
                                      n_layers=opt['rnn_num_layers'],
                                      rnn_type=opt['rnn_type'],
                                      variable_lengths=opt['variable_lengths'] > 0,
                                      pretrain=True)

        dim_word_output = opt['rnn_hidden_size'] * (2 if opt['bidirectional'] else 1)

        num_cls_word = 4  # for comparison with cmrin, 2->4 and word embedding->word context
        self.word_judge = nn.Sequential(nn.Linear(dim_word_output, opt['dim_hidden_word_judge']),
                                        nn.ReLU(),
                                        nn.Dropout(opt['word_judge_drop']),
                                        nn.Linear(opt['dim_hidden_word_judge'], num_cls_word),
                                        nn.Softmax(dim=2))


        self.clip_expression_label = nn.Sequential(nn.Linear(dim_word_output * 2, dim_word_output),
                                        nn.ReLU(),
                                        nn.Dropout(opt['word_judge_drop']),
                                        nn.Linear(dim_word_output, 1))


        self.clip_noun_label = nn.Sequential(nn.Linear(dim_word_output * 2, dim_word_output),
                                        nn.ReLU(),
                                        nn.Dropout(opt['word_judge_drop']),
                                        nn.Linear(dim_word_output, 1))
        
        self.MLP_x = MLP(opt['dim_reason'] + opt['dim_location'], opt['dim_reason'] + opt['dim_location'], 4, 3)
        self.MLP_l = MLP(opt['dim_reason'] + opt['dim_location'], opt['dim_reason'] + opt['dim_location'], 4, 3)


        # control on language
        self.controller = Controller(dim_word_output, opt['T_ctrl'])

        self.updater = GraphR(opt)

        # for comparison with cmrin, encode location feats with learned cxt feats
        self.locate_encoder = LocationEncoder(opt['vis_init_norm'], opt['dim_location'])
        
        self.matching = Matching(opt['dim_reason']+opt['dim_location'], opt['dim_reason']+opt['dim_location'], dim_word_output, opt['jemb_dim'], opt['jemb_drop_out'])

    def forward(self, visual_feature, label_feature, expression_noun, cls, lfeat, lrel, sents, sents_gt):
        context, hidden, embeded, max_length = self.rnn_encoder(sents)
        input_gcnencoder_sents = sents[:, 0:max_length]
        is_not_pad_sents = (input_gcnencoder_sents != 0).float()

        context_weight = self.word_judge(context)
        context_weight = context_weight * is_not_pad_sents.unsqueeze(2).expand(is_not_pad_sents.size(0),
                                                                               is_not_pad_sents.size(1),
                                                                               context_weight.size(2))

        expression_guided_labels, q_weights, expression_noun_avg = self.controller(context, expression_noun, label_feature, hidden, is_not_pad_sents)
        #pdb.set_trace()
        x, x_label = self.updater(visual_feature, expression_guided_labels, hidden, q_weights, embeded, cls, lrel)
        location_feature = self.locate_encoder(lfeat)
        final_x = torch.cat([x, location_feature], dim=2)
        final_l = torch.cat([x_label, location_feature], dim=2)
        #pdb.set_trace()

        #construct loss
        expression_noun_avg_expand = expression_noun_avg.unsqueeze(1).expand(expression_noun_avg.size(0), final_l.size(1), expression_noun_avg.size(1))
        expression_noun_avg_final_l = torch.cat([final_l, expression_noun_avg_expand], 2)

        #label_score
        expression_label_score = self.clip_expression_label(expression_noun_avg_final_l).squeeze(2)
        #pdb.set_trace()
        is_not_pad_node = (cls != -1.0).float()
        expression_label_weight_mid = F.softmax(expression_label_score, dim = 1)
        expression_label_weight = expression_label_weight_mid * is_not_pad_node

        expression_label_weight_sum = torch.sum(expression_label_weight, dim=1).unsqueeze(1).expand(expression_label_weight.size(0), expression_label_weight.size(1))
        expression_label_weight[expression_label_weight_sum != 0] = expression_label_weight[expression_label_weight_sum != 0] / expression_label_weight_sum[expression_label_weight_sum != 0]


        #node_score
        '''
        expression_noun_avg_x = torch.cat([final_x, expression_noun_avg_expand], 2)
        expression_node_score = self.clip_noun_label(expression_noun_avg_x).squeeze(2)

        expression_node_weight_mid = F.softmax(expression_node_score, dim = 1)
        expression_node_weight = expression_node_weight_mid * is_not_pad_node
        expression_node_weight_sum = torch.sum(expression_node_weight, dim=1).unsqueeze(1).expand(expression_node_weight.size(0), expression_node_weight.size(1))
        expression_node_weight[expression_node_weight_sum != 0] = expression_node_weight[expression_node_weight_sum != 0] / expression_node_weight_sum[expression_node_weight_sum != 0]
        '''

        #selection and fusion
        selected_num = int(expression_label_weight.size(1) / 3)
        selected_cls = torch.ones((cls.size(0), selected_num+1), requires_grad=False)
        selected_final_x = torch.zeros((final_x.size(0), selected_num+1, final_x.size(2)), requires_grad=False).cuda()
        selected_final_l = torch.zeros((final_l.size(0), selected_num+1, final_l.size(2)), requires_grad=False).cuda()
        selected_gt = torch.ones((cls.size(0),), requires_grad=False)
        #fine_label_weight = torch.zeros((selected_final_l.size(0), selected_num), requires_grad=False).cuda()
        #fine_node_weight = torch.zeros((selected_final_x.size(0), selected_num), requires_grad=False).cuda()
        idx = torch.zeros((cls.size(0), cls.size(1)), requires_grad=False)
        
        for i in range(0, expression_label_weight.size(0)):
            i_weight, i_idx = torch.sort(expression_label_weight[i], descending=True)
            idx[i] = i_idx
            #gt_index = (i_idx == sents_gt[i]).nonzero().flatten()[0]
            for j in range(0, selected_num):
                #pdb.set_trace()
                selected_final_x[i][j] = final_x[i][i_idx[j]]
                selected_final_l[i][j] = final_l[i][i_idx[j]]
                #pdb.set_trace()
                if is_not_pad_node[i][i_idx[j]] == 0:
                    #pdb.set_trace()
                    selected_cls[i][j] = 0

                #pdb.set_trace()
                if i_idx[j] == sents_gt[i]:
                    selected_gt[i] = j

            
            #pdb.set_trace()
            if sents_gt[i]  not in i_idx[0:selected_num]:
                selected_final_x[i][j+1] = final_x[i][sents_gt[i]]
                selected_final_l[i][j+1] = final_l[i][sents_gt[i]]
                selected_cls[i][j+1] = 1
                selected_gt[i] = j+1
                
            
            #fine_label_weight[i] = i_weight[:][0:selected_num]

            '''
            for j in range(0, selected_num):
                fine_node_weight[i][j] = expression_node_weight[i][i_idx[j]]
            '''

      
        #pdb.set_trace()
        #fine_node_weight_expand = fine_node_weight.unsqueeze(2).expand(fine_node_weight.size(0), fine_node_weight.size(1), selected_x.size(2))
        #fine_label_weight_expand = fine_label_weight.unsqueeze(2).expand(fine_label_weight.size(0), fine_label_weight.size(1), selected_final_l.size(2))
        #fused_fine_node_features = (fine_node_weight_expand * selected_x).sum(1)
        #fused_fine_label_features = (fine_label_weight_expand * selected_final_l).sum(1)
        #pdb.set_trace()
        x_boxes = self.MLP_x(selected_final_x)
        l_boxes = self.MLP_l(selected_final_l)
        final_cos = self.matching(selected_final_x, selected_final_l, hidden)

        # location_feature = self.locate_encoder(lfeat)
        # final_x = torch.cat([x, location_feature], dim=2)
        # final_l = torch.cat([x_label, location_feature], dim=2)
        #score_cos = self.matching(final_x, final_l, hidden)
        return final_cos, selected_gt, selected_cls, idx, x_boxes, l_boxes


class LocationEncoder(nn.Module):
    def __init__(self, init_norm, dim):
        super(LocationEncoder, self).__init__()
        self.lfeat_normalizer = NormalizeScale(5, init_norm)
        self.fc = nn.Linear(5, dim)

    def forward(self, lfeats):
        loc_feat = self.lfeat_normalizer(lfeats)
        output = self.fc(loc_feat)
        return output
