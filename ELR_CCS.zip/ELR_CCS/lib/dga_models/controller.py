import torch
import torch.nn as nn
from torch.nn.parameter import Parameter
import math
import torch.nn.functional as F
import pdb


class Controller(nn.Module):

    def __init__(self, dim_word_output, T_ctrl):
        super(Controller, self).__init__()
        ctrl_dim = dim_word_output

        # define c_0 and reset_parameters
        self.c_init = Parameter(torch.FloatTensor(1, ctrl_dim))
        self.reset_parameters()

        #self.sub = nn.Linear(ctrl_dim, 1)
        #expression_guided categorical label
        self.word_trans = nn.Linear(1024, 512)
        self.label_trans = nn.Linear(512, 512)
        self.label_word_match = nn.Sequential(nn.Tanh(),
                                             nn.Linear(512, 1))

        self.fuse = nn.Linear(1024+512, 1024)

        self.sub = nn.Linear(ctrl_dim, 1)
        #nn.Softmax(dim=2)
        #self.T_ctrl = T_ctrl

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.c_init.size(1))
        self.c_init.data.uniform_(-stdv, stdv)

    def forward(self, lstm_seq, expression_noun, label_feature, q_encoding, attn_mask):
        #expression_guided categorical labels
        #pdb.set_trace()
        word_trans = self.word_trans(lstm_seq)
        label_trans = self.label_trans(label_feature)
        #pdb.set_trace()
        word_tans_expand = word_trans.unsqueeze(2).expand(word_trans.size(0), word_trans.size(1), label_trans.size(1), word_trans.size(2))
        label_trans_expand = label_trans.unsqueeze(1).expand(label_trans.size(0), word_trans.size(1), label_trans.size(1), label_trans.size(2))
        label_word = self.label_word_match(word_tans_expand + label_trans_expand).squeeze(3)
        mask = (1.0 - attn_mask.float()) * (-1e30)
        mask_expand = mask.unsqueeze(2).expand(mask.size(0), mask.size(1), label_word.size(2))
        mask_label_word = label_word + mask_expand
        #pdb.set_trace()
        expression_based_weight_t = F.softmax(mask_label_word, dim = 1)
        attn_mask_expand = attn_mask.unsqueeze(2).expand(attn_mask.size(0), attn_mask.size(1), label_word.size(2)).float()
        expression_based_weight =  expression_based_weight_t * attn_mask_expand


        for i in range(0, expression_based_weight.size(2)):
            #pdb.set_trace()
            temp = expression_based_weight[:,:,i]
            temp_weight_sum = torch.sum(temp, dim=1).unsqueeze(1).expand(temp.size(0), temp.size(1))
            temp[temp_weight_sum != 0] = temp[temp_weight_sum != 0] / temp_weight_sum[temp_weight_sum != 0]
            expression_based_weight[:,:,i] = temp
            del temp
        #pdb.set_trace()
        expression_based_weight_expand = expression_based_weight.unsqueeze(3).expand(expression_based_weight.size(0),expression_based_weight.size(1), expression_based_weight.size(2), lstm_seq.size(2))
        lstm_seq_expand = lstm_seq.unsqueeze(2).expand(lstm_seq.size(0), lstm_seq.size(1), expression_based_weight.size(2), lstm_seq.size(2))
        expression_guided_labels = torch.sum(expression_based_weight_expand * lstm_seq_expand,dim=1)
        # sub_weight_sum = torch.sum(sub_weight, dim=1).unsqueeze(1).expand(sub_weight.size(0), sub_weight.size(1))
        # sub_weight[sub_weight_sum != 0] = sub_weight[sub_weight_sum != 0] / sub_weight_sum[sub_weight_sum != 0]
        #pdb.set_trace()
        updated_expression_guided_labels = self.fuse(torch.cat([label_feature, expression_guided_labels], 2))
        q_scores = self.sub(lstm_seq).squeeze(2) + mask
        q_weight_t = F.softmax(q_scores, dim = 1) 
        q_weight = q_weight_t * attn_mask.float()
        q_weight_sum = torch.sum(q_weight, dim=1).unsqueeze(1).expand(q_weight.size(0), q_weight.size(1))
        q_weight[q_weight_sum != 0] = q_weight[q_weight_sum != 0] / q_weight_sum[q_weight_sum != 0]
        #pdb.set_trace()
        clip_weight = 1 / 3 * torch.ones((expression_noun.size(0), expression_noun.size(2)), requires_grad=False).cuda()
        expression_noun_avg = expression_noun.sum(dim = 1) * clip_weight
        expression_noun_avg = expression_noun.sum(dim = 1) * clip_weight



        # intra_score = self.intra(lstm_seq).squeeze(2) + mask
        # inter_score = self.inter(lstm_seq).squeeze(2) + mask

        
        # sub_weight_t = F.softmax(sub_score, dim = 1) 
        # intra_weight_t = F.softmax(intra_score, dim = 1) 
        # inter_weight_t = F.softmax(inter_score, dim = 1)

        # sub_weight = sub_weight_t * attn_mask.float()
        # intra_weight = intra_weight_t * attn_mask.float()
        # inter_weight = inter_weight_t * attn_mask.float()


        

        # sub_weight_sum = torch.sum(sub_weight, dim=1).unsqueeze(1).expand(sub_weight.size(0), sub_weight.size(1))
        # sub_weight[sub_weight_sum != 0] = sub_weight[sub_weight_sum != 0] / sub_weight_sum[sub_weight_sum != 0]

        # intra_weight_sum = torch.sum(intra_weight, dim=1).unsqueeze(1).expand(intra_weight.size(0), intra_weight.size(1))
        # intra_weight[intra_weight_sum != 0] = intra_weight[intra_weight_sum != 0] / intra_weight_sum[intra_weight_sum != 0]

        # inter_weight_sum = torch.sum(inter_weight, dim=1).unsqueeze(1).expand(inter_weight.size(0), inter_weight.size(1))
        # inter_weight[inter_weight_sum != 0] = inter_weight[inter_weight_sum != 0] / inter_weight_sum[inter_weight_sum != 0]
        # #pdb.set_trace()
        
        # clip_weight = 1 / 3 * torch.ones((expression_noun.size(0), expression_noun.size(2)), requires_grad=False).cuda()
        # expression_noun_avg = expression_noun.sum(dim = 1) * clip_weight



        return updated_expression_guided_labels, q_weight, expression_noun_avg
